module.exports = {
  search: require('./Search'),
  sendMessage: require('./SendMessage'),
  createMessage: require('./CreateMessage'),
};
